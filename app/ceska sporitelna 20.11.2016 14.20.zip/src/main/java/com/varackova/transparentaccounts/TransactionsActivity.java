package com.varackova.transparentaccounts;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;

import com.squareup.otto.Bus;
import com.squareup.otto.Subscribe;
import com.varackova.transparentaccounts.DetailActivity;
import com.varackova.transparentaccounts.R;
import com.varackova.transparentaccounts.rest.BusProvider;
import com.varackova.transparentaccounts.rest.event.AccountTransactionsLoadedEvent;
import com.varackova.transparentaccounts.rest.event.LoadAccountTransactionsEvent;

/**
 * Created by mndrnk on 2016-11-20.
 */
public class TransactionsActivity extends AppCompatActivity{

    private String mAccountNumber;
    private Bus mBus;
    private int mPage = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transactions);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Intent intent = getIntent();
        mAccountNumber = intent.getStringExtra(DetailActivity.ACCOUNT_NUMBER);

        mBus = BusProvider.getInstance();//todo parent for all activities with Bus and toolbar

    }


    @Override
    public void onResume() {
        super.onResume();

        mBus.register(this);
        mBus.post(new LoadAccountTransactionsEvent(mAccountNumber, mPage));
    }

    @Override
    public void onPause() {
        super.onPause();
        mBus.unregister(this);
    }

    @Subscribe
    public void onAccountTransactionsLoaded(AccountTransactionsLoadedEvent event) {
        //todo
        Log.d("asdf", "transastionc loaded");
    }

}
