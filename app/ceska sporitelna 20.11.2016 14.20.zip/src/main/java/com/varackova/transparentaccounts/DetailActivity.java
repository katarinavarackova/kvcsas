package com.varackova.transparentaccounts;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.squareup.otto.Bus;
import com.squareup.otto.Subscribe;
import com.varackova.transparentaccounts.rest.BusProvider;
import com.varackova.transparentaccounts.rest.event.AccountDetailLoadedEvent;
import com.varackova.transparentaccounts.rest.event.LoadAccountDetailEvent;

/**
 * Created by mndrnk on 2016-11-20.
 */
public class DetailActivity extends AppCompatActivity {
    public static final String ACCOUNT_NUMBER = "ACCOUNT_NUMBER";
    private Bus mBus;

    private String mAccountNumber;

    private TextView mAccountNumberView;
    private TextView mAccountNameView;
    private TextView mBankCodeView;
    private TextView mTransparencyFromView;
    private TextView mTransparencyToView;
    private TextView mPublicationToView;
    private TextView mActualizationDateView;
    private TextView mBalanceView;
    private TextView mCurrencyView;
    private TextView mIbanView;
    private TextView mNoteView;
    private Activity mActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mActivity = this;

        Intent intent = getIntent();
        mAccountNumber = intent.getStringExtra(ACCOUNT_NUMBER);

        mBus = BusProvider.getInstance();//todo parent for all activities with Bus and toolbar

        initViews();
    }


    @Override
    public void onResume() {
        super.onResume();

        mBus.register(this);
        mBus.post(new LoadAccountDetailEvent(mAccountNumber));
    }

    @Override
    public void onPause() {
        super.onPause();
        mBus.unregister(this);
    }

    private void initViews() {
        mAccountNumberView = (TextView) findViewById(R.id.accountNumber);
        mAccountNameView = (TextView) findViewById(R.id.accountName);
        mBankCodeView = (TextView) findViewById(R.id.bankCode);
        mTransparencyFromView = (TextView) findViewById(R.id.transparencyFrom);
        mTransparencyToView = (TextView) findViewById(R.id.transparencyTo);
        mPublicationToView = (TextView) findViewById(R.id.publicationTo);
        mActualizationDateView = (TextView) findViewById(R.id.actualizationDate);
        mBalanceView = (TextView) findViewById(R.id.balance);
        mCurrencyView = (TextView) findViewById(R.id.currency);
        mIbanView = (TextView) findViewById(R.id.iban);
        mNoteView = (TextView) findViewById(R.id.note);

        Button showTransactionsButton = (Button) findViewById(R.id.showTransactions);
        View.OnClickListener buttonOnClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mActivity, TransactionsActivity.class);
                intent.putExtra(DetailActivity.ACCOUNT_NUMBER, mAccountNumber);
                startActivity(intent);
            }
        };
        showTransactionsButton.setOnClickListener(buttonOnClickListener);
    }

    @Subscribe
    public void onAccountDetailLoaded(AccountDetailLoadedEvent event) {
        mAccountNumberView.setText(event.getAccountDetail().getAccountNumber());
        mAccountNameView.setText(event.getAccountDetail().getName());
        mBankCodeView.setText(event.getAccountDetail().getBankCode());
        mTransparencyFromView.setText(event.getAccountDetail().getTransparencyFrom());
        mTransparencyToView.setText(event.getAccountDetail().getTransparencyTo());
        mPublicationToView.setText(event.getAccountDetail().getPublicationTo());
        mActualizationDateView.setText(event.getAccountDetail().getActualizationDate());
        mBalanceView.setText(String.valueOf(event.getAccountDetail().getBalance()));
        mCurrencyView.setText(event.getAccountDetail().getCurrency());
        mIbanView.setText(event.getAccountDetail().getIban());
        mNoteView.setText(event.getAccountDetail().getNote());
    }

}
