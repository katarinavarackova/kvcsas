package com.varackova.transparentaccounts.rest.event;

import com.varackova.transparentaccounts.data.Transactions;

/**
 * Event posted when transactions on account are loaded
 */
public class AccountTransactionsLoadedEvent {
    private Transactions mTransactions;

    public AccountTransactionsLoadedEvent(Transactions transactions) {
        mTransactions = transactions;
    }

    public Transactions getAccountTransactions() {
        return mTransactions;
    }
}
